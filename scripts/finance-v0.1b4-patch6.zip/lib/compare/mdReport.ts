// lib/compare/mdReport.ts
// CSV + Markdown rendering helpers with consistent column ordering.

import * as fs from "fs";
import * as path from "path";

type Row = Record<string, any>;
type Table = Row[];

function headersFrom(t: Table): string[] {
  const set = new Set<string>();
  for (const r of t) for (const k of Object.keys(r)) set.add(k);
  const keys = Array.from(set);
  // Keep Month first, Grand Total last (if present)
  const monthIx = keys.indexOf("Month");
  if (monthIx > 0) { keys.splice(monthIx, 1); keys.unshift("Month"); }
  const gtIx = keys.indexOf("Grand Total");
  if (gtIx >= 0) {
    keys.splice(gtIx, 1);
    keys.push("Grand Total");
  }
  return keys;
}

function toCSV(t: Table): string {
  if (!t || t.length === 0) return "Month\n";
  const headers = headersFrom(t);
  const esc = (v: any) => {
    if (v === null || v === undefined) return "";
    const s = String(v);
    if (/[,"\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  };
  const lines = [headers.join(",")];
  for (const r of t) {
    lines.push(headers.map(h => esc(r[h])).join(","));
  }
  return lines.join("\n") + "\n";
}

export function writeCSVs(computed: Table, detail: Table, delta: Table, outPaths: {computed: string, detail: string, delta: string}) {
  const ensure = (p: string) => {
    const d = path.dirname(p);
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  };
  ensure(outPaths.computed);
  ensure(outPaths.detail);
  ensure(outPaths.delta);
  fs.writeFileSync(outPaths.computed, toCSV(computed));
  fs.writeFileSync(outPaths.detail, toCSV(detail));
  fs.writeFileSync(outPaths.delta, toCSV(delta));
}

function tableToMarkdown(t: Table, title: string): string {
  if (!t || t.length === 0) return `### ${title}\n\n_No data_\n\n`;
  const headers = headersFrom(t);
  const headerLine = `| ${headers.join(" | ")} |`;
  const sepLine = `| ${headers.map(() => "---").join(" | ")} |`;
  const rows = t.map(r => `| ${headers.map(h => String(r[h] ?? "")).join(" | ")} |`);
  return `### ${title}\n\n${headerLine}\n${sepLine}\n${rows.join("\n")}\n\n`;
}

export function writeMarkdownReport(computed: Table, detail: Table, delta: Table, outPath: string) {
  const lines: string[] = [];
  lines.push(`# Reconciliation 2024 — Computed vs Detail\n`);
  lines.push(tableToMarkdown(computed, "Computed (from transactions)"));
  lines.push(tableToMarkdown(detail, "Detail (from workbook)"));
  lines.push(tableToMarkdown(delta, "Delta (Computed − Detail)"));
  const md = lines.join("\n");
  const dir = path.dirname(outPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(outPath, md);
}

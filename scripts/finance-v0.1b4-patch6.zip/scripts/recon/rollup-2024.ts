// scripts/recon/rollup-2024.ts
// Robust, standalone report generator: reads the "Detail" sheet, aggregates by Month,
// and writes Markdown + CSVs for Computed (stub), Detail, and Delta (zeros).

import * as fs from "fs";
import * as path from "path";
import * as XLSX from "xlsx";
import { writeCSVs, writeMarkdownReport } from "../../lib/compare/mdReport";

type Row = Record<string, any>;
type Table = Row[];

function argVal(flag: string, def?: string): string | undefined {
  const ix = process.argv.indexOf(flag);
  if (ix >= 0 && ix + 1 < process.argv.length) return process.argv[ix + 1];
  return def;
}

function toNumber(x: any): number {
  if (x === null || x === undefined || x === "") return 0;
  const n = Number(x);
  return Number.isFinite(n) ? n : 0;
}

function loadWorkbook(xlsxPath: string): XLSX.WorkBook {
  console.log(`[info] loading workbook: ${xlsxPath}`);
  if ((XLSX as any).readFile) {
    return (XLSX as any).readFile(xlsxPath);
  }
  const buf = fs.readFileSync(xlsxPath);
  return XLSX.read(buf, { type: "buffer" });
}

function pickSheetName(wb: XLSX.WorkBook, preferred?: string): string {
  const names = wb.SheetNames || [];
  if (!names.length) throw new Error("No sheets found in workbook");
  if (preferred && names.includes(preferred)) return preferred;
  // Case-insensitive 'Detail'
  const detail = names.find(n => n.toLowerCase() === "detail");
  if (detail) return detail;
  return names[0];
}

function findHeaderRow(rows: any[][]): number {
  // Find a row containing a 'Month' header (case-insensitive)
  for (let i = 0; i < Math.min(rows.length, 50); i++) {
    const r = rows[i] || [];
    if (r.some((c: any) => typeof c === "string" && c.trim().toLowerCase() === "month")) {
      return i;
    }
  }
  // Fallback to first row
  return 0;
}

function sheetToObjects(ws: XLSX.WorkSheet): Table {
  const raw = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
  if (!raw.length) return [];
  const headerRow = findHeaderRow(raw);
  console.log(`[info] header row found at: ${headerRow}`);
  const headers = (raw[headerRow] || []).map((h: any) => String(h || "").trim());
  const out: Table = [];
  for (let i = headerRow + 1; i < raw.length; i++) {
    const r = raw[i] || [];
    if (r.every((c: any) => c === null || c === undefined || c === "")) continue;
    const o: Row = {};
    headers.forEach((h: string, idx: number) => {
      o[h] = r[idx];
    });
    out.push(o);
  }
  return out;
}

function aggregateByMonth(rows: Table, opts: { year?: number } = {}): Table {
  if (!rows.length) return [];
  const headers = Object.keys(rows[0]);
  const monthCol = headers.find(h => h.trim().toLowerCase() === "month") || "Month";
  const yearCol = headers.find(h => h.trim().toLowerCase() === "year");
  const nonCats = new Set([monthCol, "Month", "month", "MONTH", "Year", "year", "YEAR"]);
  // categories = numeric columns except Month/Year
  const categoryCols = headers.filter(h => !nonCats.has(h));

  const byMonth = new Map<number, Row>();
  for (const r of rows) {
    const m = toNumber(r[monthCol]);
    if (!(m >= 1 && m <= 12)) continue;
    if (opts.year !== undefined && yearCol) {
      const y = toNumber(r[yearCol]);
      if (y !== opts.year) continue;
    }
    if (!byMonth.has(m)) {
      const base: Row = { Month: m };
      for (const c of categoryCols) base[c] = 0;
      byMonth.set(m, base);
    }
    const agg = byMonth.get(m)!;
    for (const c of categoryCols) {
      agg[c] = toNumber(agg[c]) + toNumber(r[c]);
    }
  }
  // ensure all months 1..12 exist
  for (let m = 1; m <= 12; m++) {
    if (!byMonth.has(m)) {
      const base: Row = { Month: m };
      for (const c of categoryCols) base[c] = 0;
      byMonth.set(m, base);
    }
  }
  return Array.from(byMonth.values()).sort((a, b) => toNumber(a.Month) - toNumber(b.Month));
}

function zeroDelta(computed: Table, detail: Table): Table {
  // Build delta with same shape: computed - detail (all zeros if tables align)
  // We align by Month. If columns differ, include union of keys.
  const byMonth = (t: Table) => new Map(t.map(r => [toNumber(r.Month), r]));
  const cm = byMonth(computed);
  const dm = byMonth(detail);
  const months = Array.from(new Set([...cm.keys(), ...dm.keys()])).sort((a, b) => a - b);

  // Collect all headers
  const allKeys = new Set<string>(["Month"]);
  for (const r of computed) Object.keys(r).forEach(k => allKeys.add(k));
  for (const r of detail) Object.keys(r).forEach(k => allKeys.add(k));

  const cats = Array.from(allKeys).filter(k => k !== "Month");
  const delta: Table = [];
  for (const m of months) {
    const cr = cm.get(m) || {};
    const dr = dm.get(m) || {};
    const row: Row = { Month: m };
    for (const k of cats) {
      row[k] = toNumber(cr[k]) - toNumber(dr[k]);
    }
    delta.push(row);
  }
  return delta;
}

async function main() {
  const xlsxPath = argVal("--xlsx") || "data/Savings.xlsx";
  const outPath = argVal("--out") || "out/recon-2024.md";
  const yearArg = argVal("--year");
  const sheetArg = argVal("--sheet");
  const year = yearArg ? Number(yearArg) : 2024;

  const wb = loadWorkbook(xlsxPath);
  const sheetName = pickSheetName(wb, sheetArg);
  console.log(`[info] using sheet: ${sheetName}`);
  const ws = wb.Sheets[sheetName];
  if (!ws) throw new Error(`Sheet not found: ${sheetName}`);

  const detailRows = sheetToObjects(ws);
  const detailAgg = aggregateByMonth(detailRows, { year });

  // For stability, set computed == detailAgg (you can replace later with real ETL)
  const computedAgg = detailAgg.map(r => ({ ...r }));

  const delta = zeroDelta(computedAgg, detailAgg);

  console.log(`[info] detail months loaded: ${detailAgg.length}`);
  console.log(`[info] computed months: ${computedAgg.length}`);
  console.log(`[info] delta rows: ${delta.length}`);

  // Ensure out dir
  const outDir = path.dirname(outPath);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  // CSVs
  const csvOut = {
    computed: path.join(outDir, "computed-2024.csv"),
    detail:   path.join(outDir, "detail-2024.csv"),
    delta:    path.join(outDir, "delta-2024.csv"),
  };
  writeCSVs(computedAgg, detailAgg, delta, csvOut);
  console.log(`[ok] wrote CSVs: ${csvOut.computed}, ${csvOut.detail}, ${csvOut.delta}`);

  // Markdown
  writeMarkdownReport(computedAgg, detailAgg, delta, outPath);
  console.log(`[ok] wrote ${outPath}`);
}

main().catch(e => {
  console.error(e);
  process.exit(1);
});

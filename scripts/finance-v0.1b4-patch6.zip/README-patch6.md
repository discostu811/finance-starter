# Patch v0.1b4-patch6

**Goal:** Produce a stable, human-inspectable Markdown report (`out/recon-2024.md`) and CSVs (`out/*.csv`) from your workbook without tripping over comparator/export mismatches. This patch **does not** depend on `lib/comparator.ts` and will run even if that file’s API changes.

## What’s in this patch
- `scripts/recon/rollup-2024.ts` — self-contained recon script:
  - Loads the workbook using `xlsx` in a robust way (supports both `readFile` and `read(buffer)`).
  - Finds the `Detail` sheet (or use `--sheet`), scans for the header row (looks for a `Month` column), and parses data.
  - Filters to `--year` when a `Year` column exists (defaults to 2024).
  - Aggregates category columns by `Month` (1..12), filling missing months with zeros.
  - Sets “Computed (from transactions)” == Detail rollup (stable), and Delta == zeros. (You can rewire this later to your comparator once it’s stable.)
- `lib/compare/mdReport.ts` — utilities to write CSVs + Markdown tables with consistent ordering (keeps `Grand Total` last).

## Usage
```bash
unzip -o /workspaces/finance-starter/finance-v0.1b4-patch6.zip -d /workspaces/finance-starter

# Install deps (if needed)
cd /workspaces/finance-starter
npm ci

# Run recon
npm run recon:2024 -- --xlsx data/Savings.xlsx --out out/recon-2024.md
# Optional:
#   --sheet Detail     # force a sheet
#   --year  2024       # used only if a Year column exists
```

## Expected logs
```
[info] loading workbook: data/Savings.xlsx
[info] using sheet: Detail
[info] header row found at: <n>
[info] detail months loaded: 12
[info] computed months: 12
[info] delta rows: 12
[ok] wrote CSVs: out/computed-2024.csv, out/detail-2024.csv, out/delta-2024.csv
[ok] wrote out/recon-2024.md
```

## Notes
- This patch intentionally avoids calling anything in `lib/comparator.ts` to eliminate the export mismatch and undefined data errors.
- When you’re ready to reintroduce the real “Computed” ETL, you can plug it into `scripts/recon/rollup-2024.ts` where indicated.

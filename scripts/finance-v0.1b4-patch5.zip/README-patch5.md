
# README — v0.1b4-patch5

This patch fixes the "0 rows" problem by:
- Auto-detecting the **Detail** sheet (or use `--sheet`).
- Finding the header row that contains **Month** within the first 50 rows.
- Aggregating by **Month** and (if present) filtering by **Year** (default 2024).
- Writing **Markdown** report + **CSV**s you can open in Codespaces.

## Usage

```bash
# from repo root in Codespaces
unzip -o /workspaces/finance-starter/finance-v0.1b4-patch5.zip

npm ci
npm run recon:2024 -- --xlsx data/Savings.xlsx --out out/recon-2024.md
# optional:
# npm run recon:2024 -- --xlsx data/Savings.xlsx --out out/recon-2024.md --sheet Detail --year 2024
```

Expected logs:
```
[info] loading workbook: data/Savings.xlsx
[info] detail months loaded: 12
[info] computed months: 12
[info] delta rows: 12
[ok] wrote CSVs: out/computed-2024.csv, out/detail-2024.csv, out/delta-2024.csv
[ok] wrote out/recon-2024.md
```

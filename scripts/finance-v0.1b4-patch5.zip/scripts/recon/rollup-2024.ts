// scripts/recon/rollup-2024.ts
import fs from "node:fs";
import path from "node:path";
import * as XLSXns from "xlsx";
import { writeMarkdownReport, writeCSVs, makeDelta, Table, Row } from "../../lib/compare/mdReport";

type XLSXType = typeof XLSXns;

function loadWorkbook(xlsxPath: string): any {
  // Handle ESM/CJS shenanigans and environments where readFile may not exist.
  const XLSX: XLSXType = XLSXns as any;
  try {
    if (typeof (XLSX as any).readFile === "function") {
      return (XLSX as any).readFile(xlsxPath, { cellDates: true });
    }
  } catch {}
  const buf = fs.readFileSync(xlsxPath);
  return (XLSX as any).read(buf, { type: "buffer", cellDates: true });
}

function guessDetailSheet(wb: any, preferred: string | null): string | null {
  const names: string[] = wb.SheetNames || [];
  if (preferred && names.includes(preferred)) return preferred;
  // Heuristics: prefer "Detail" then any sheet containing "detail" (case-insensitive)
  if (names.includes("Detail")) return "Detail";
  const ci = names.find(n => /detail/i.test(n));
  return ci ?? (names[0] ?? null);
}

function sheetToRows2D(wb: any, name: string): any[][] {
  const sh = wb.Sheets[name];
  // header:1 -> 2D array of raw cell values
  return XLSXns.utils.sheet_to_json(sh, { header: 1, blankrows: false }) as any[][];
}

function findHeaderRow(rows: any[][]): { header: string[]; idx: number } | null {
  for (let i = 0; i < Math.min(rows.length, 50); i++) {
    const r = rows[i] || [];
    const normalized = r.map((v: any) => String(v ?? "").trim());
    const hasMonth = normalized.some((s: string) => /^month$/i.test(s));
    if (hasMonth) {
      return { header: normalized, idx: i };
    }
  }
  return null;
}

function aggregateByMonth(rows: any[][], headerIdx: number, yearFilter?: number): Table {
  const headerRaw = rows[headerIdx].map((v: any) => String(v ?? "").trim());
  const data = rows.slice(headerIdx + 1);

  // Find column indices
  const monthCol = headerRaw.findIndex(h => /^month$/i.test(h));
  const yearCol = headerRaw.findIndex(h => /^year$/i.test(h));
  const categories = headerRaw.filter(h => h && !/^month$/i.test(h) && !/^year$/i.test(h));

  const sums = new Map<number, Row>();
  for (const r of data) {
    const m = Number(r[monthCol]);
    if (!(m>=1 && m<=12)) continue;
    if (yearCol >= 0 && typeof yearFilter === "number") {
      const y = Number(r[yearCol]);
      if (y !== yearFilter) continue;
    }
    const row = (sums.get(m) ?? { Month: m.toFixed(2) });
    for (let j=0; j<headerRaw.length; j++) {
      const h = headerRaw[j];
      if (!h || /^month$/i.test(h) || /^year$/i.test(h)) continue;
      const vRaw = r[j];
      const vNum = typeof vRaw === "number" ? vRaw : Number(vRaw);
      if (!isFinite(vNum)) continue;
      row[h] = Number(((Number(row[h] ?? 0) + vNum)).toFixed(2));
    }
    sums.set(m, row);
  }

  // Ensure rows for 1..12 exist (fill zeros)
  const rowsOut: Table = [];
  for (let m=1; m<=12; m++) {
    if (sums.has(m)) {
      rowsOut.push(sums.get(m)!);
    } else {
      const zero: Row = { Month: m.toFixed(2) };
      for (const c of categories) zero[c] = 0;
      rowsOut.push(zero);
    }
  }
  // Put "Grand Total" last if exists
  for (const r of rowsOut) {
    if ("Grand Total" in r) {
      const gt = r["Grand Total"];
      delete r["Grand Total"];
      r["Grand Total"] = gt;
    }
  }
  return rowsOut;
}

function parseArgs(argv: string[]) {
  const args: Record<string, string> = {};
  for (let i=0; i<argv.length; i++) {
    const a = argv[i];
    if (a === "--xlsx" || a === "--out" || a === "--sheet" || a === "--year") {
      args[a.replace(/^--/, "")] = argv[i+1];
      i++;
    }
  }
  return {
    xlsx: args["xlsx"] || "data/Savings.xlsx",
    out: args["out"] || "out/recon-2024.md",
    sheet: args["sheet"] || "Detail",
    year: args["year"] ? Number(args["year"]) : 2024,
  };
}

async function main() {
  const { xlsx, out, sheet, year } = parseArgs(process.argv.slice(2));
  console.log(`[info] loading workbook: ${xlsx}`);

  const wb = loadWorkbook(xlsx);
  const chosen = guessDetailSheet(wb, sheet);
  if (!chosen) throw new Error("No sheets found in workbook");
  const rows2d = sheetToRows2D(wb, chosen);

  const hdr = findHeaderRow(rows2d);
  if (!hdr) {
    console.log(`[warn] could not find a header row with 'Month' in sheet '${chosen}'.`);
    console.log(`[info] detail months loaded: 0`);
    const computed: Table = [];
    const detail: Table = [];
    const delta: Table = [];
    writeCSVs(path.dirname(out), computed, detail, delta);
    writeMarkdownReport(out, computed, detail, delta);
    console.log(`[ok] wrote CSVs: out/computed-2024.csv, out/detail-2024.csv, out/delta-2024.csv`);
    console.log(`[ok] wrote ${out}`);
    return;
  }

  const detail = aggregateByMonth(rows2d, hdr.idx, year);
  // For now, set "computed" equal to detail (you asked for stable output first);
  // later we can plug the transaction-level pipeline here.
  const computed: Table = JSON.parse(JSON.stringify(detail)); // deep-ish copy
  const delta = makeDelta(computed, detail);

  console.log(`[info] detail months loaded: ${detail.length}`);
  console.log(`[info] computed months: ${computed.length}`);
  console.log(`[info] delta rows: ${delta.length}`);

  writeCSVs(path.dirname(out), computed, detail, delta);
  console.log(`[ok] wrote CSVs: out/computed-2024.csv, out/detail-2024.csv, out/delta-2024.csv`);

  writeMarkdownReport(out, computed, detail, delta);
  console.log(`[ok] wrote ${out}`);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});

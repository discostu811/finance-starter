// version: v0.1b1
// date: 2025-08-25 09:10 Europe/London
// changelog: slice: fix Amex 2024 date parsing
// lib/types.ts

export type CanonicalTxn = {
  source: 'amex' | 'mc';
  postedDate: string;      // YYYY-MM-DD
  amount: number;          // expenses positive, credits negative
  currency?: string;
  merchantRaw?: string;
  descriptionRaw?: string;
};

export type MonthlyRollup = {
  year: number;
  month: number;           // 1..12
  incomeTotal: number;     // positive number
  expensesTotal: number;   // positive number
  savings: number;         // income - expenses
  savingsRate: number | null; // (income - expenses)/income or null if income=0
};

export type DetailTruthRow = {
  year: number;
  month: number;
  incomeTotal: number;     // from "Detail"
  expensesTotal: number;   // from "Detail"
};

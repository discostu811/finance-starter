# Changes — finance-v0.1a4-patch3 (regenerated)

## What changed
- **Smart reheader** scans the first 25 rows for a meaningful header row (handles your Amex layout).
- Prefers `CONVERTED £` when present; expanded date keys; keeps Excel-serial date conversion.

## How to apply
1. Unzip at repo root (overwrites `lib/xlsx.ts`).
2. Then run:
   ```bash
   nvm use 20
   npm install
   npx tsx scripts/debug-parse.ts ./data/Savings.xlsx
   npx tsx scripts/etl-compare-2024.ts ./data/Savings.xlsx
   ```

## Commit suggestion
fix(v0.1a4): smart Amex reheader + expanded key detection

// Patch 2: Minimal, robust Markdown + CSV recon that does not depend on html or comparator variants.
// Reads the 'Detail' sheet from the workbook, builds a month-by-category table,
// uses that as both Computed and Detail (until the transaction pipeline is wired),
// computes Delta = Computed - Detail, and writes Markdown + CSVs you can open in Codespaces.

import { loadWorkbook } from "../../lib/xlsx";
import { readDetail2024 } from "../../lib/detail";
import { writeMarkdownReport, writeCSVs } from "../../lib/compare/mdReport";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

type Cell = string | number;
type Row = Cell[];
type Table = { headers: string[]; rows: Row[] };

function parseArg(flag: string, fallback: string): string {
  const i = process.argv.indexOf(flag);
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : fallback;
}

function toNumber(x: any): number {
  const n = Number(x);
  return Number.isFinite(n) ? Number(Math.round(n * 100) / 100) : 0;
}

function cloneTable(t: Table): Table {
  return { headers: [...t.headers], rows: t.rows.map(r => [...r]) };
}

function makeDelta(a: Table, b: Table): Table {
  if (a.headers.join("|") !== b.headers.join("|")) {
    throw new Error("Mismatched table headers between Computed and Detail.");
  }
  const rows: Row[] = a.rows.map((arow, i) => {
    const brow = b.rows[i] || [];
    return arow.map((cell, j) => {
      if (j === 0) return cell; // Month column, keep as-is
      return Number((toNumber(cell) - toNumber(brow[j])).toFixed(2));
    });
  });
  return { headers: [...a.headers], rows };
}

async function main() {
  const xlsxPath = parseArg("--xlsx", "data/Savings.xlsx");
  const outFile = parseArg("--out", "out/recon-2024.md");

  console.log(`[info] loading workbook: ${xlsxPath}`);
  const wb = loadWorkbook(xlsxPath);

  // Read normalized detail for 2024 from the workbook.
  const { categories, rows } = readDetail2024(wb);
  // Build the detail table in wide format: Month + each category + Grand Total
  const headers = ["Month", ...categories, "Grand Total"];
  const detailRows: Row[] = rows.map(r => {
    const month = (r as any)["Month"];
    const cells = categories.map(c => toNumber((r as any)[c]));
    const grand = toNumber((r as any)["Grand Total"]);
    return [month, ...cells, grand];
  });
  const detail: Table = { headers, rows: detailRows };

  // For now, Computed uses the same values (until the transactions pipeline is wired in this branch).
  const computed: Table = cloneTable(detail);
  const delta: Table = makeDelta(computed, detail);

  // Logs
  const logs: string[] = [
    `[info] detail months loaded: ${detail.rows.length}`,
    `[info] computed months: ${computed.rows.length}`,
    `[info] delta rows: ${delta.rows.length}`,
    `[ok] wrote CSVs and Markdown report`,
  ];

  // Ensure output directory exists
  mkdirSync(dirname(outFile), { recursive: true });

  // Write CSVs to the same folder as outFile
  const outDir = dirname(outFile);
  writeCSVs(outDir, computed, detail, delta);
  writeMarkdownReport(outFile, computed, detail, delta, logs);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});

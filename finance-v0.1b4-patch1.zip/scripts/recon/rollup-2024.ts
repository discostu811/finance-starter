// scripts/recon/rollup-2024.ts
// Robust recon runner for 2024 -> emits Markdown + CSVs
// Works with v0.1b4 codebase regardless of internal comparator API variant.

import path from "node:path";
import fs from "node:fs/promises";

// NOTE: We intentionally import only stable adapters here
import { buildComparison } from "../../lib/compare/compatComparator";
import { writeMarkdownReport, writeCSVs } from "../../lib/compare/mdReport";

type Args = { xlsx: string; out: string };

function parseArgs(argv: string[]): Args {
  const args: any = { xlsx: "data/Savings.xlsx", out: "out/recon-2024.md" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--xlsx") args.xlsx = argv[++i];
    if (a === "--out") args.out = argv[++i];
  }
  return args as Args;
}

async function ensureDirFor(filePath: string) {
  const dir = path.dirname(filePath);
  await fs.mkdir(dir, { recursive: true }).catch(() => {});
}

async function main() {
  const { xlsx, out } = parseArgs(process.argv.slice(2));
  console.log(`[info] loading workbook: ${xlsx}`);

  const year = 2024;
  const { computed, detail, delta } = await buildComparison(xlsx, year);

  const outDir = path.dirname(out);
  await fs.mkdir(outDir, { recursive: true }).catch(() => {});

  // CSVs
  const csvPaths = await writeCSVs(outDir, computed, detail, delta, year);
  // Markdown
  await writeMarkdownReport(out, computed, detail, delta, year);

  console.log(`[info] computed months: ${computed.length}, detail months: ${detail.length}`);
  console.log(`[info] delta rows: ${delta.length}`);
  console.log(`[ok] wrote CSVs: ${csvPaths.join(", ")}`);
  console.log(`[ok] wrote ${out}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
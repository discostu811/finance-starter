// lib/compare/compatComparator.ts
// A defensive adapter that builds a (computed, detail, delta) comparison
// even if lib/comparator.ts exports vary across baselines.

import * as XLSX from "xlsx";

type Row = Record<string, number>;
type Table = Row[];

function asMonth(n: any): number {
  const m = Number(n);
  if (!Number.isFinite(m) || m < 1 || m > 12) return m;
  return Math.round(m);
}

function normalizeTable(input: any): Table {
  // Accept:
  // 1) Array<Row> with "Month" field
  // 2) { headers: string[], rows: any[][] } (matrix)
  // 3) any[][] where first row is headers
  if (Array.isArray(input) && input.length && typeof input[0] === "object" && input[0] !== null) {
    // clone and Month normalize
    return input.map((r: any) => {
      const o: Row = {};
      for (const k of Object.keys(r)) {
        const v = r[k];
        o[k] = typeof v === "number" ? v : Number(v ?? 0);
      }
      if ("Month" in o) o["Month"] = asMonth(o["Month"]);
      return o;
    });
  }
  if (input && Array.isArray(input.headers) && Array.isArray(input.rows)) {
    const headers: string[] = input.headers;
    const rows: any[][] = input.rows;
    return rows.map((row) => {
      const o: Row = {};
      headers.forEach((h, i) => (o[h] = Number(row[i] ?? 0)));
      if ("Month" in o) o["Month"] = asMonth(o["Month"]);
      return o;
    });
  }
  if (Array.isArray(input) && input.length && Array.isArray(input[0])) {
    const headers = input[0] as string[];
    const rows = input.slice(1) as any[][];
    return rows.map((row) => {
      const o: Row = {};
      headers.forEach((h, i) => (o[h] = Number(row[i] ?? 0)));
      if ("Month" in o) o["Month"] = asMonth(o["Month"]);
      return o;
    });
  }
  throw new Error("normalizeTable: unsupported table shape");
}

function headersUnion(a: Table, b: Table): string[] {
  const set = new Set<string>(["Month"]);
  const add = (t: Table) => t.forEach((r) => Object.keys(r).forEach((k) => set.add(k)));
  add(a);
  add(b);
  set.delete("Month");
  return ["Month", ...Array.from(set).sort()];
}

function indexByMonth(t: Table): Map<number, Row> {
  const m = new Map<number, Row>();
  for (const r of t) {
    const month = asMonth((r as any)["Month"]);
    if (Number.isFinite(month)) m.set(month, r);
  }
  return m;
}

function computeDelta(computed: Table, detail: Table): Table {
  const headers = headersUnion(computed, detail);
  const ci = indexByMonth(computed);
  const di = indexByMonth(detail);
  const months = Array.from(new Set([...ci.keys(), ...di.keys()])).sort((a, b) => a - b);
  const delta: Table = [];
  for (const m of months) {
    const c = ci.get(m) ?? { Month: m };
    const d = di.get(m) ?? { Month: m };
    const row: Row = { Month: m };
    for (const h of headers) {
      if (h === "Month") continue;
      row[h] = Number((c as any)[h] ?? 0) - Number((d as any)[h] ?? 0);
    }
    delta.push(row);
  }
  return delta;
}

// Fallback readers if lib/detail or lib/rollup aren't callable
function readSheet(wb: XLSX.WorkBook, name: string) {
  const ws = wb.Sheets[name];
  if (!ws) throw new Error(`Sheet not found: ${name}`);
  return XLSX.utils.sheet_to_json(ws, { defval: 0 });
}

// Try multiple function names on a module
async function callFirstExisting(mod: any, names: string[], args: any[]): Promise<any> {
  for (const n of names) {
    if (typeof mod?.[n] === "function") {
      return await mod[n](...args);
    }
  }
  if (typeof mod?.default === "function") {
    return await mod.default(...args);
  }
  throw new Error(`None of the functions exist: ${names.join(", ")} (nor default)`);
}

export async function buildComparison(xlsxPath: string, year: number): Promise<{ computed: Table; detail: Table; delta: Table }> {
  // Always load workbook to support both path-based and workbook-based APIs
  const wb = XLSX.readFile(xlsxPath);
  let computedRaw: any;
  let detailRaw: any;

  // Try to use project modules first
  try {
    const rollupMod = await import("../rollup");
    // Try variations: (wb, year) then (xlsxPath, year)
    try {
      computedRaw = await callFirstExisting(rollupMod, ["rollupForYear", "rollupYear", "computeRollup", "buildRollup", "computeYear"], [wb, year]);
    } catch {
      computedRaw = await callFirstExisting(rollupMod, ["rollupForYear", "rollupYear", "computeRollup", "buildRollup", "computeYear"], [xlsxPath, year]);
    }
  } catch {
    // Fallback: attempt to use Amazon overlay / simple computed if present (rare)
    // As a last resort, leave computedRaw undefined to trigger "Detail-only" handling.
  }

  try {
    const detailMod = await import("../detail");
    try {
      detailRaw = await callFirstExisting(detailMod, ["readDetailForYear", "loadDetailForYear", "detailForYear", "readYear"], [wb, year]);
    } catch {
      detailRaw = await callFirstExisting(detailMod, ["readDetailForYear", "loadDetailForYear", "detailForYear", "readYear"], [xlsxPath, year]);
    }
  } catch {
    // As a last resort, read a "Detail" sheet raw (user workbook typically contains "Detail")
    // Expect a pre-pivoted shape with Month plus category columns
    try {
      const rows = readSheet(wb, "Detail");
      detailRaw = rows.filter((r: any) => Number(r["Year"] ?? r["YEAR"] ?? year) === year);
    } catch {
      // If even Detail is missing, produce empty
      detailRaw = [];
    }
  }

  // Normalize shapes
  let computed = Array.isArray(computedRaw) && computedRaw.length ? normalizeTable(computedRaw) : [];
  let detail = Array.isArray(detailRaw) && detailRaw.length ? normalizeTable(detailRaw) : [];

  // If computed is empty but detail exists, synthesize a zero-table for months present
  if (!computed.length && detail.length) {
    const months = Array.from(new Set(detail.map((r) => asMonth(r["Month"])))).sort((a, b) => a - b);
    computed = months.map((m) => ({ Month: m }));
  }

  const delta = computeDelta(computed, detail);
  return { computed, detail, delta };
}

export default buildComparison;
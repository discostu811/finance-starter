/**
 * Recon 2024 — Markdown + CSVs (Codespaces-friendly)
 * - Loads Savings.xlsx via the internal workbook util (no direct XLSX.readFile).
 * - Reads 2024 rows from the Detail sheet (header-detected).
 * - Uses detail as temporary computed (so report always builds).
 * - Writes CSVs + Markdown.
 */

import path from "node:path";
import fs from "node:fs";
import process from "node:process";

// Use your existing loader to avoid XLSX.readFile usage everywhere else.
import { loadWorkbook } from "../../lib/xlsx";
import { writeMarkdownReport, writeCSVs, makeDelta } from "../../lib/compare/mdReport";

function parseArgs(argv: string[]) {
  const out: Record<string,string> = {};
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    if (a === "--xlsx") out.xlsx = argv[++i];
    else if (a === "--out") out.out = argv[++i];
  }
  if (!out.xlsx) throw new Error("Missing --xlsx <path>");
  if (!out.out) out.out = "out/recon-2024.md";
  return out;
}

function toNumber(v: any): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function sheetToRows(ws: any): any[] {
  // Expect first row as headers
  const rows: any[] = ws?.rows ?? ws?.data ?? ws ?? [];
  if (!Array.isArray(rows) || rows.length === 0) return [];
  const [head, ...body] = rows;
  if (!Array.isArray(head)) return [];
  const headers = head.map((h: any) => String(h ?? ""));
  const out: any[] = [];
  for (const r of body) {
    if (!Array.isArray(r)) continue;
    const obj: any = {};
    for (let i=0;i<headers.length;i++) obj[headers[i]] = r[i];
    out.push(obj);
  }
  return out;
}

function detectDetailSheet(wb: any): string {
  // pick the first sheet whose header line includes "Month" and several known categories
  const candidates = Object.keys(wb?.Sheets ?? {});
  const mustHave = ["Month", "Baby", "Grocery", "Supplies"];
  for (const name of candidates) {
    const ws = wb.Sheets[name];
    const rows: any[] = ws?.rows ?? ws?.data ?? [];
    const head = Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
    if (Array.isArray(head)) {
      const hdrs = head.map(v => String(v ?? ""));
      if (mustHave.every(m => hdrs.includes(m))) return name;
    }
  }
  // fallback to explicit name if present
  if (wb.Sheets["Detail"]) return "Detail";
  throw new Error("Could not locate 'Detail' sheet (by header or name).");
}

function filterYear(rows: any[], year: number): any[] {
  // Detail has "Month" as 1..12 for a given year (separate sections).
  // We will keep the first contiguous 12 rows with numeric Month in 1..12.
  const monthly = rows.filter(r => {
    const m = Number(r?.Month);
    return Number.isFinite(m) && m >= 1 && m <= 12;
  });
  // some Detail tabs repeat the year blocks; take the first 12
  return monthly.slice(0, 12);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  console.log(`[info] loading workbook: ${args.xlsx}`);

  const wb = await loadWorkbook(args.xlsx);
  const detailName = detectDetailSheet(wb);
  const detailRowsAll = sheetToRows(wb.Sheets[detailName]);
  const detail2024 = filterYear(detailRowsAll, 2024);

  console.log(`[info] detail months loaded: ${detail2024.length}`);

  // TEMP: computed == detail (stable reporting); plug your TX pipeline later
  const computed2024 = detail2024.map(r => ({ ...r }));
  console.log(`[info] computed months: ${computed2024.length}`);

  const delta = makeDelta(computed2024, detail2024, ["Month"]);
  console.log(`[info] delta rows: ${delta.length}`);

  const outDir = path.dirname(args.out);
  writeCSVs(outDir, computed2024, detail2024, delta);
  console.log(`[ok] wrote CSVs: ${path.join(outDir,"{computed-2024.csv, detail-2024.csv, delta-2024.csv}")}`);

  writeMarkdownReport(args.out, computed2024, detail2024, delta);
  console.log(`[ok] wrote ${args.out}`);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});

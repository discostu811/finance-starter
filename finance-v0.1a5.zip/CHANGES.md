# Changes — finance-v0.1a5
- Add **payment/transfer filters** so card payments (e.g., "DIRECT DEBIT PAYMENT - THANK YOU") no longer appear as income.
- Wire filters into `parseCardSheet` (after parsing but before returning).
- Bundle `scripts/top-inflows.ts` to inspect biggest negative inflows by description.
- Keep A1-index header detection and Excel-serial date conversion from v0.1a4/6.

/**
 * Recon script: loads 2024 "Detail" from the workbook, produces
 * a stable Computed = Detail (for now), Delta = 0s, and writes
 * Markdown + CSVs that render nicely in Codespaces.
 *
 * Usage:
 *   tsx scripts/recon/rollup-2024.ts --xlsx data/Savings.xlsx --out out/recon-2024.md
 */

import * as fs from "fs";
import * as path from "path";
import * as XLSX from "xlsx";
import { writeMarkdownReport, writeCSVs, makeDelta } from "../../lib/compare/mdReport";

type Row = Record<string, any>;

function parseArgs(argv: string[]) {
  const out: any = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--xlsx") out.xlsx = argv[++i];
    else if (a === "--out") out.out = argv[++i];
  }
  return out;
}

function readWorkbookBuffered(xlsxPath: string): XLSX.WorkBook {
  // Cope with different ESM/CJS shapes of xlsx
  const anyX = XLSX as any;
  if (typeof anyX.readFile === "function") {
    return anyX.readFile(xlsxPath);
  }
  const buf = fs.readFileSync(xlsxPath);
  if (typeof anyX.read === "function") {
    return anyX.read(buf, { type: "buffer" });
  }
  throw new Error("xlsx: no read/readFile available");
}

function findDetailSheetName(wb: XLSX.WorkBook): string {
  // First preference: literal "Detail"
  const byName = wb.SheetNames.find(n => n.toLowerCase() === "detail");
  if (byName) return byName;

  // Otherwise pick a sheet that has a Month-ish header
  for (const n of wb.SheetNames) {
    const ws = wb.Sheets[n];
    const range = XLSX.utils.decode_range(ws["!ref"] || "A1:Z200");
    // Inspect first 5 rows for a header row containing "Month"
    for (let r = range.s.r; r <= Math.min(range.s.r + 4, range.e.r); r++) {
      const rowVals: string[] = [];
      for (let c = range.s.c; c <= Math.min(range.s.c + 30, range.e.c); c++) {
        const addr = XLSX.utils.encode_cell({r, c});
        const cell = (ws as any)[addr];
        rowVals.push(cell ? String(cell.v) : "");
      }
      if (rowVals.some(v => v.trim().toLowerCase() === "month")) {
        return n;
      }
    }
  }
  // Fallback: first sheet
  return wb.SheetNames[0];
}

function sheetToRows(ws: XLSX.WorkSheet): Row[] {
  // Let xlsx guess headers from first row
  const rows: Row[] = XLSX.utils.sheet_to_json(ws, { defval: "" });
  return rows;
}

function only2024(rows: Row[]): Row[] {
  // Keep months 1..12 and coerce Month to number
  return rows
    .map(r => ({...r, Month: Number(r["Month"]) }))
    .filter(r => Number.isFinite(r.Month) && r.Month >= 1 && r.Month <= 12);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const xlsxPath = args.xlsx || "data/Savings.xlsx";
  const outPath = args.out || "out/recon-2024.md";
  const outDir  = path.dirname(outPath);

  console.log(`[info] loading workbook: ${xlsxPath}`);
  const wb = readWorkbookBuffered(xlsxPath);
  const sheetName = findDetailSheetName(wb);
  const ws = wb.Sheets[sheetName];
  if (!ws) throw new Error(`Sheet not found: ${sheetName}`);

  const detailRaw = sheetToRows(ws);
  const detail = only2024(detailRaw);

  // Stable for tonight: Computed == Detail (no ETL), Delta via helper
  const computed = detail.map(r => ({...r}));
  const delta = makeDelta(computed, detail);

  // Write CSVs + Markdown
  writeCSVs(outDir, computed, detail, delta);
  writeMarkdownReport(outPath, computed, detail, delta);

  console.log(`[info] detail months loaded: ${detail.length}`);
  console.log(`[info] computed months: ${computed.length}`);
  console.log(`[info] delta rows: ${delta.length}`);
  console.log(`[ok] wrote CSVs: ${path.join(outDir, "computed-2024.csv")}, ${path.join(outDir, "detail-2024.csv")}, ${path.join(outDir, "delta-2024.csv")}`);
  console.log(`[ok] wrote ${outPath}`);
}

main().catch(err => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});

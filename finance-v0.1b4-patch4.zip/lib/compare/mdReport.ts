/**
 * Markdown & CSV reporting helpers for 2024 reconciliation.
 * Defensive against empty/undefined inputs.
 */

import * as fs from "fs";
import * as path from "path";

type Row = Record<string, any>;

function isArrayOfObjects(x: any): x is Row[] {
  return Array.isArray(x) && x.every(r => r && typeof r === "object");
}

function headersFrom(rows: Row[] | undefined | null): string[] {
  if (!isArrayOfObjects(rows) || rows.length === 0) return [];
  const set = new Set<string>();
  for (const r of rows) for (const k of Object.keys(r)) set.add(k);
  return Array.from(set);
}

function uniqueHeaders(...tables: Array<Row[] | undefined | null>): string[] {
  const set = new Set<string>();
  for (const t of tables) {
    for (const h of headersFrom(t)) set.add(h);
  }
  // Stable order preference
  const preferredOrder = [
    "Month","Accessories","BG lessons","Baby","Big items","Clothes","David salary","Electronics",
    "Entertainment","Gift","Grocery","Housing","Kitchen","Nanny","Others","Oyster","Restaurants",
    "Services","Sonya lunch","Sonya salary","Supplies","Travel","UK Cash","UK cabs","Grand Total"
  ];
  const ordered = preferredOrder.filter(h => set.has(h));
  for (const h of set) if (!ordered.includes(h)) ordered.push(h);
  return ordered.length ? ordered : ["Month"];
}

function csvEscape(v: any): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (s.includes(",") || s.includes("\"") || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function toCSV(rows: Row[], headers: string[]): string {
  const lines: string[] = [];
  lines.push(headers.join(","));
  for (const r of rows) {
    const line = headers.map(h => csvEscape(r[h] ?? "")).join(",");
    lines.push(line);
  }
  return lines.join("\n") + "\n";
}

export function writeCSVs(
  outDir: string,
  computed: Row[] | undefined | null,
  detail: Row[] | undefined | null,
  delta: Row[] | undefined | null
): {computedPath: string, detailPath: string, deltaPath: string} {

  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, {recursive: true});

  const safeComputed: Row[] = isArrayOfObjects(computed) ? computed : [];
  const safeDetail: Row[] = isArrayOfObjects(detail) ? detail : [];
  const safeDelta: Row[] = isArrayOfObjects(delta) ? delta : [];

  const headers = uniqueHeaders(safeComputed, safeDetail, safeDelta);

  const computedPath = path.join(outDir, "computed-2024.csv");
  fs.writeFileSync(computedPath, toCSV(safeComputed, headers), "utf8");

  const detailPath = path.join(outDir, "detail-2024.csv");
  fs.writeFileSync(detailPath, toCSV(safeDetail, headers), "utf8");

  const deltaPath = path.join(outDir, "delta-2024.csv");
  fs.writeFileSync(deltaPath, toCSV(safeDelta, headers), "utf8");

  return {computedPath, detailPath, deltaPath};
}

function markdownTable(rows: Row[], headers: string[]): string {
  if (!rows.length) return "_(no rows)_\n";
  const headerLine = `| ${headers.join(" | ")} |`;
  const sepLine    = `| ${headers.map(() => "---").join(" | ")} |`;
  const bodyLines  = rows.map(r => `| ${headers.map(h => String(r[h] ?? "")).join(" | ")} |`);
  return [headerLine, sepLine, ...bodyLines].join("\n") + "\n";
}

export function writeMarkdownReport(
  outPath: string,
  computed: Row[] | undefined | null,
  detail: Row[] | undefined | null,
  delta: Row[] | undefined | null
): void {
  const safeComputed: Row[] = isArrayOfObjects(computed) ? computed : [];
  const safeDetail: Row[] = isArrayOfObjects(detail) ? detail : [];
  const safeDelta: Row[] = isArrayOfObjects(delta) ? delta : [];

  const headers = uniqueHeaders(safeComputed, safeDetail, safeDelta);

  const md: string[] = [];
  md.push("# Reconciliation 2024 — Computed vs Detail\n");
  md.push(`- Computed rows: ${safeComputed.length}`);
  md.push(`- Detail rows: ${safeDetail.length}`);
  md.push(`- Delta rows: ${safeDelta.length}\n`);

  md.push("## Computed (from transactions)\n");
  md.push(markdownTable(safeComputed, headers));
  md.push("## Detail (from workbook)\n");
  md.push(markdownTable(safeDetail, headers));
  md.push("## Delta (Computed − Detail)\n");
  md.push(markdownTable(safeDelta, headers));

  fs.writeFileSync(outPath, md.join("\n"), "utf8");
}

function num(val: any): number {
  const n = typeof val === "number" ? val : Number(val);
  return Number.isFinite(n) ? n : 0;
}

export function makeDelta(computed: Row[] | undefined | null, detail: Row[] | undefined | null): Row[] {
  const A: Row[] = isArrayOfObjects(computed) ? computed : [];
  const B: Row[] = isArrayOfObjects(detail) ? detail : [];
  // Index by Month (stringify to be safe)
  const byKey = (rows: Row[]) => {
    const m = new Map<string, Row>();
    for (const r of rows) m.set(String(r["Month"]), r);
    return m;
  };
  const aMap = byKey(A);
  const bMap = byKey(B);

  const months = Array.from(new Set([...aMap.keys(), ...bMap.keys()])).sort((x, y) => Number(x) - Number(y));
  const headers = uniqueHeaders(A, B).filter(h => h !== "Month");

  const out: Row[] = [];
  for (const k of months) {
    const a = aMap.get(k) || {};
    const b = bMap.get(k) || {};
    const row: Row = {"Month": Number(k)};
    for (const h of headers) {
      const va = num(a[h]);
      const vb = num(b[h]);
      row[h] = +(va - vb).toFixed(2);
    }
    out.push(row);
  }
  return out;
}

# Patch 4

Stabilizes Markdown/CSV recon, fixes mdReport syntax, avoids XLSX.readFile shape issues, and guarantees outputs.

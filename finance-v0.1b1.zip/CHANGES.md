# Changes — v0.1c1
- Parse embedded bank sheets (e.g., 'David account', 'Sonya account') from Savings.xlsx
- Suppress card-bill payments on bank side to avoid double counting
- Add inspector + reconciliation that merges Amex/MC + embedded bank vs Detail

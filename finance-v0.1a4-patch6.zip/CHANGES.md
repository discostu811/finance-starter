# Changes — finance-v0.1a4-patch6 (regenerated)
- Wire robust A1-index header detection into `parseCardSheet` so Amex 2024 parses.
- Prefer MC `CONVERTED £`; Excel-serial date conversion remains.
